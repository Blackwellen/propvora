# Propvora Next.js Landing Page

This is a full Next.js App Router implementation of the generated Propvora landing page design.

## What is included

- Floating premium top navigation
- Propvora logo asset derived from the provided real brand reference
- Hero copy and CTAs
- Integrated generated hero dashboard image: `public/images/propvora-hero-dashboard.png`
- Trust row
- Operation type cards
- Feature grid
- Operating mode cards
- Before/after value comparison
- Platform overview/table/map/mobile mockup
- Supplier marketplace section
- Pricing section using the checked current site pricing:
  - Starter £29/mo
  - Operator £79/mo
  - Scale £149/mo
- Testimonials/outcomes
- Final CTA
- Footer
- Full responsive CSS

## Install

```bash
npm install
npm run dev
```

Open `http://localhost:3000`.

## Files to copy into an existing Next.js project

- `app/page.tsx`
- `app/globals.css`
- `public/images/propvora-logo.png`
- `public/images/propvora-mark.png`
- `public/images/propvora-hero-dashboard.png`

If your project already has a layout and global CSS, merge the CSS variables and classes carefully instead of replacing your whole `globals.css`.
