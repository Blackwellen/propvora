import Image from "next/image";

type Card = {
  title: string;
  body: string;
  icon: string;
};

type PricingPlan = {
  name: string;
  price: string;
  descriptor: string;
  bullets: string[];
  featured?: boolean;
};

const navItems = ["Stays", "Suppliers", "Services", "Emergency", "Features", "Pricing", "About"];

const trustLogos = [
  "URBAN NEST",
  "BRIDGEWATER",
  "NORTHPOINT",
  "STONEHAVEN",
  "SOVEREIGN",
  "LONDON STAY CO.",
];

const operationTypes: Card[] = [
  {
    title: "Long-term lets",
    icon: "users",
    body: "Manage assured shorthold tenancies with ease.",
  },
  {
    title: "HMOs",
    icon: "home",
    body: "Per-room management built for HMOs.",
  },
  {
    title: "Rent-to-rent",
    icon: "switch",
    body: "Track rent, deals and guarantees.",
  },
  {
    title: "Serviced accommodation",
    icon: "briefcase",
    body: "Streamline guest stays and turnovers.",
  },
  {
    title: "Student lets",
    icon: "cap",
    body: "Academic-year tenancies made simple.",
  },
  {
    title: "Mixed portfolios",
    icon: "building",
    body: "Residential, commercial and everything in between.",
  },
  {
    title: "Commercial",
    icon: "case",
    body: "Leases, assets and service charges.",
  },
];

const featureCards: Card[] = [
  {
    title: "Portfolio & Tenancy",
    icon: "building",
    body: "Manage properties, units, tenancies and lease data from one place.",
  },
  {
    title: "Bookings & Guest Experience",
    icon: "spark",
    body: "Direct bookings, guest messaging and stay management.",
  },
  {
    title: "Supplier Marketplace",
    icon: "store",
    body: "Find, vet and book trusted contractors in minutes.",
  },
  {
    title: "Compliance & Certificates",
    icon: "shield",
    body: "Track certificates, licences and inspections effortlessly.",
  },
  {
    title: "Finance & Invoicing",
    icon: "wallet",
    body: "Invoicing, payments, expenses and cash flow in real time.",
  },
  {
    title: "Automations",
    icon: "bolt",
    body: "Automate workflows, reminders and recurring tasks.",
  },
  {
    title: "AI Copilot",
    icon: "ai",
    body: "Smart insights, summaries and answers across your portfolio.",
  },
  {
    title: "Multi-currency & International",
    icon: "globe",
    body: "Operate across borders with local currency and tax handling.",
  },
  {
    title: "Team & Workspace",
    icon: "team",
    body: "Roles, permissions and collaboration built for teams.",
  },
];

const modes = [
  {
    title: "Serviced Accommodation",
    visual: "visual-sa",
    bullets: [
      "Booking engine & channels",
      "Guest experience tools",
      "Cleaning & turnover tasks",
      "Dynamic pricing",
    ],
  },
  {
    title: "Residential",
    visual: "visual-residential",
    bullets: [
      "Rent & arrears tracking",
      "Deposit & renewal flows",
      "Gas/EPC/EICR compliance",
      "Tenant portal",
    ],
  },
  {
    title: "HMO",
    visual: "visual-hmo",
    bullets: [
      "Per-room tenancies",
      "HMO licence tracking",
      "Shared-area certificates",
      "Room-level management",
    ],
  },
  {
    title: "Commercial",
    visual: "visual-commercial",
    bullets: [
      "Commercial leases",
      "Service-charge handling",
      "Mixed-use portfolios",
      "Asset management",
    ],
  },
];

const comparisonRows = [
  ["Scattered spreadsheets & tools", "Unified workspace"],
  ["Missed compliance dates", "Auto reminders & expiry tracking"],
  ["Email job tracking", "Structured work hub"],
  ["Manual rent chasing", "Arrears dashboard"],
  ["Multiple subscriptions", "One connected platform"],
];

const modules = [
  "Property Management",
  "Unit Management",
  "Tenancy Management",
  "Work Management",
  "Supplier Management",
  "Calendar & Scheduling",
  "Invoicing & Payments",
  "AI Copilot",
];

const supplierTrades = [
  { title: "Plumbing & Heating", icon: "tap", rating: "4.8", pros: "120+ pros" },
  { title: "Electrical", icon: "bolt", rating: "4.8", pros: "150+ pros" },
  { title: "Gas Safe", icon: "warning", rating: "4.9", pros: "90+ pros" },
  { title: "Roofing", icon: "roof", rating: "4.7", pros: "110+ pros" },
  { title: "Cleaning", icon: "clean", rating: "4.8", pros: "200+ pros" },
  { title: "Locksmith", icon: "lock", rating: "4.8", pros: "80+ pros" },
  { title: "Pest Control", icon: "bug", rating: "4.7", pros: "70+ pros" },
];

const pricingPlans: PricingPlan[] = [
  {
    name: "Starter",
    price: "£29",
    descriptor: "For individual landlords getting organised.",
    bullets: [
      "Up to 5 properties",
      "1 team seat",
      "Portfolio, Work, Contacts & Calendar",
      "Compliance & rent tracking",
      "Email support",
    ],
  },
  {
    name: "Operator",
    price: "£79",
    descriptor: "For active portfolio operators.",
    featured: true,
    bullets: [
      "Up to 25 properties",
      "3 team seats",
      "Advanced reports",
      "Booking management",
      "Priority email support",
    ],
  },
  {
    name: "Scale",
    price: "£149",
    descriptor: "For growing portfolios and small teams.",
    bullets: [
      "Up to 100 properties",
      "10 team seats",
      "AI Copilot",
      "Direct booking pages",
      "Portals & accounting",
    ],
  },
];

const testimonials = [
  {
    quote:
      "Propvora has transformed how we run our serviced accommodation business. Everything from bookings to cleaning and compliance is in one place now.",
    name: "James Whitaker",
    role: "Founder, Urban Stay Co.",
    tag: "Serviced Accommodation",
    initials: "JW",
  },
  {
    quote:
      "Managing HMOs used to be chaos. Propvora’s per-room tenancies, compliance tracking and supplier access save me hours every week.",
    name: "Sarah Khan",
    role: "Director, Northpoint Property",
    tag: "HMO Operator",
    initials: "SK",
  },
  {
    quote:
      "The arrears dashboard and automated reminders have improved our cash flow dramatically. Highly recommended.",
    name: "Daniel Morris",
    role: "Portfolio Manager, Bridgewater Estates",
    tag: "Rent-to-Rent",
    initials: "DM",
  },
];

function Icon({ name, className = "" }: { name: string; className?: string }) {
  const common = {
    width: 22,
    height: 22,
    viewBox: "0 0 24 24",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg",
    className,
  };

  const stroke = {
    stroke: "currentColor",
    strokeWidth: 1.9,
    strokeLinecap: "round" as const,
    strokeLinejoin: "round" as const,
  };

  switch (name) {
    case "users":
      return (
        <svg {...common}>
          <path {...stroke} d="M16 21v-2a4 4 0 0 0-4-4H7a4 4 0 0 0-4 4v2" />
          <path {...stroke} d="M9.5 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8Z" />
          <path {...stroke} d="M22 21v-2a4 4 0 0 0-3-3.87" />
          <path {...stroke} d="M16 3.13a4 4 0 0 1 0 7.75" />
        </svg>
      );
    case "home":
      return (
        <svg {...common}>
          <path {...stroke} d="m3 10 9-7 9 7" />
          <path {...stroke} d="M5 9.5V21h14V9.5" />
          <path {...stroke} d="M9 21v-6h6v6" />
        </svg>
      );
    case "switch":
      return (
        <svg {...common}>
          <path {...stroke} d="M17 3l4 4-4 4" />
          <path {...stroke} d="M3 7h18" />
          <path {...stroke} d="m7 21-4-4 4-4" />
          <path {...stroke} d="M21 17H3" />
        </svg>
      );
    case "briefcase":
    case "case":
      return (
        <svg {...common}>
          <path {...stroke} d="M10 6V5a2 2 0 0 1 2-2h0a2 2 0 0 1 2 2v1" />
          <path {...stroke} d="M4 7h16v12H4z" />
          <path {...stroke} d="M4 12h16" />
        </svg>
      );
    case "cap":
      return (
        <svg {...common}>
          <path {...stroke} d="m22 10-10-5-10 5 10 5 10-5Z" />
          <path {...stroke} d="M6 12v5c3.5 2.2 8.5 2.2 12 0v-5" />
        </svg>
      );
    case "building":
      return (
        <svg {...common}>
          <path {...stroke} d="M4 21V5a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v16" />
          <path {...stroke} d="M16 9h3a1 1 0 0 1 1 1v11" />
          <path {...stroke} d="M8 7h4M8 11h4M8 15h4" />
        </svg>
      );
    case "spark":
    case "ai":
      return (
        <svg {...common}>
          <path {...stroke} d="m12 2 1.8 5.1L19 9l-5.2 1.9L12 16l-1.8-5.1L5 9l5.2-1.9L12 2Z" />
          <path {...stroke} d="m19 15 .8 2.2L22 18l-2.2.8L19 21l-.8-2.2L16 18l2.2-.8L19 15Z" />
        </svg>
      );
    case "store":
      return (
        <svg {...common}>
          <path {...stroke} d="M4 10h16l-1.2-5H5.2L4 10Z" />
          <path {...stroke} d="M6 10v10h12V10" />
          <path {...stroke} d="M9 20v-5h6v5" />
        </svg>
      );
    case "shield":
      return (
        <svg {...common}>
          <path {...stroke} d="M12 22s8-4 8-11V5l-8-3-8 3v6c0 7 8 11 8 11Z" />
          <path {...stroke} d="m9 12 2 2 4-4" />
        </svg>
      );
    case "wallet":
      return (
        <svg {...common}>
          <path {...stroke} d="M4 7h16v12H4z" />
          <path {...stroke} d="M16 12h4v4h-4a2 2 0 0 1 0-4Z" />
          <path {...stroke} d="M6 7V5h11v2" />
        </svg>
      );
    case "bolt":
      return (
        <svg {...common}>
          <path {...stroke} d="M13 2 4 14h7l-1 8 10-13h-7l0-7Z" />
        </svg>
      );
    case "globe":
      return (
        <svg {...common}>
          <circle {...stroke} cx="12" cy="12" r="9" />
          <path {...stroke} d="M3 12h18M12 3c2.5 2.3 3.6 5.3 3.6 9S14.5 18.7 12 21c-2.5-2.3-3.6-5.3-3.6-9S9.5 5.3 12 3Z" />
        </svg>
      );
    case "team":
      return (
        <svg {...common}>
          <path {...stroke} d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" />
          <circle {...stroke} cx="9" cy="7" r="4" />
          <path {...stroke} d="M23 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75" />
        </svg>
      );
    case "tap":
      return (
        <svg {...common}>
          <path {...stroke} d="M8 6h9M12 6V3M15 6v4H9a4 4 0 0 0-4 4v2" />
          <path {...stroke} d="M7 18a2 2 0 1 1-4 0c0-1.1 2-3 2-3s2 1.9 2 3Z" />
        </svg>
      );
    case "warning":
      return (
        <svg {...common}>
          <path {...stroke} d="M12 3 2 21h20L12 3Z" />
          <path {...stroke} d="M12 9v5M12 17h.01" />
        </svg>
      );
    case "roof":
      return (
        <svg {...common}>
          <path {...stroke} d="M3 12 12 4l9 8" />
          <path {...stroke} d="M5 10v10h14V10" />
        </svg>
      );
    case "clean":
      return (
        <svg {...common}>
          <path {...stroke} d="M5 21h14M7 21l1-9h8l1 9M9 12V6a3 3 0 0 1 6 0v6" />
          <path {...stroke} d="M10 16h4" />
        </svg>
      );
    case "lock":
      return (
        <svg {...common}>
          <rect {...stroke} x="5" y="10" width="14" height="11" rx="2" />
          <path {...stroke} d="M8 10V7a4 4 0 0 1 8 0v3" />
        </svg>
      );
    case "bug":
      return (
        <svg {...common}>
          <path {...stroke} d="M8 7a4 4 0 0 1 8 0v10a4 4 0 0 1-8 0V7Z" />
          <path {...stroke} d="M3 13h5M16 13h5M5 7l3 2M19 7l-3 2M5 19l3-2M19 19l-3-2M12 3v4" />
        </svg>
      );
    default:
      return (
        <svg {...common}>
          <circle {...stroke} cx="12" cy="12" r="9" />
          <path {...stroke} d="m9 12 2 2 4-4" />
        </svg>
      );
  }
}

function CheckIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 16 16" aria-hidden="true">
      <path
        d="m4 8.1 2.35 2.35L12.2 4.6"
        fill="none"
        stroke="currentColor"
        strokeLinecap="round"
        strokeLinejoin="round"
        strokeWidth="1.8"
      />
    </svg>
  );
}

function Header() {
  return (
    <header className="site-header" aria-label="Main navigation">
      <div className="nav-shell">
        <a className="brand" href="#" aria-label="Propvora home">
          <Image
            src="/images/propvora-logo.png"
            alt="Propvora"
            width={176}
            height={58}
            priority
          />
        </a>
        <nav className="nav-links" aria-label="Primary navigation">
          {navItems.map((item) => (
            <a href={`#${item.toLowerCase().replace(/\s+/g, "-")}`} key={item}>
              {item}
            </a>
          ))}
        </nav>
        <div className="nav-actions">
          <a className="sign-in" href="#">Sign in</a>
          <a className="btn btn-ghost" href="#demo">Book a demo</a>
          <a className="btn btn-primary" href="#pricing">Get started</a>
        </div>
      </div>
    </header>
  );
}

function Hero() {
  return (
    <section className="hero section-pad">
      <div className="hero-copy">
        <div className="eyebrow">
          <Icon name="spark" />
          The all-in-one platform for property operators
        </div>
        <h1>
          Run every property
          <span> operation with </span>
          <strong>clarity,</strong>
          <em> control,</em> and <strong className="purple">confidence.</strong>
        </h1>
        <p className="hero-sub">
          Propvora unifies property operations, compliance, planning, work management,
          tenancies, suppliers, and financial control in one connected platform.
          Replace spreadsheets, scattered tools, and manual admin with one intelligent workspace.
        </p>

        <div className="hero-actions">
          <a className="btn btn-primary btn-large" href="#pricing">
            Start free trial <span>→</span>
          </a>
          <a className="btn btn-soft btn-large" href="#demo">
            Book a demo
          </a>
        </div>

        <div className="trust-points" aria-label="Trial benefits">
          <span><CheckIcon /> No credit card required</span>
          <span><Icon name="bolt" /> Setup in minutes</span>
          <span><CheckIcon /> Cancel anytime</span>
        </div>
      </div>

      <div className="hero-visual" aria-label="Propvora dashboard preview">
        <Image
          src="/images/propvora-hero-dashboard.png"
          alt="Propvora portfolio operations dashboard preview"
          width={990}
          height={630}
          priority
          className="dashboard-image"
        />
      </div>
    </section>
  );
}

function TrustBar() {
  return (
    <section className="trust-row" aria-label="Trusted by property operators">
      <p>Trusted by property operators across the UK and beyond</p>
      <div className="logo-row">
        {trustLogos.map((logo) => (
          <div className="customer-logo" key={logo}>
            <span className="mini-building" />
            {logo}
          </div>
        ))}
      </div>
    </section>
  );
}

function OperationTypes() {
  return (
    <section className="section" id="features">
      <div className="section-heading compact">
        <h2>Built for every property operation type</h2>
      </div>
      <div className="operation-grid">
        {operationTypes.map((item) => (
          <article className="operation-card" key={item.title}>
            <div className="icon-badge"><Icon name={item.icon} /></div>
            <h3>{item.title}</h3>
            <p>{item.body}</p>
          </article>
        ))}
      </div>
    </section>
  );
}

function FeatureGrid() {
  return (
    <section className="section">
      <div className="section-heading compact">
        <h2>Everything you need in one connected platform</h2>
      </div>
      <div className="feature-grid">
        {featureCards.map((feature, index) => (
          <article className={`feature-card tint-${(index % 5) + 1}`} key={feature.title}>
            <div className="feature-icon"><Icon name={feature.icon} /></div>
            <div>
              <h3>{feature.title}</h3>
              <p>{feature.body}</p>
            </div>
          </article>
        ))}
      </div>
    </section>
  );
}

function OperatingModes() {
  return (
    <section className="section mode-section">
      <div className="section-heading compact">
        <h2>One platform, four operating modes</h2>
      </div>
      <div className="mode-grid">
        {modes.map((mode) => (
          <article className="mode-card" key={mode.title}>
            <div className={`mode-visual ${mode.visual}`} aria-hidden="true">
              <span />
              <span />
              <span />
            </div>
            <div className="mode-content">
              <h3>{mode.title}</h3>
              <ul>
                {mode.bullets.map((bullet) => (
                  <li key={bullet}><CheckIcon /> {bullet}</li>
                ))}
              </ul>
            </div>
          </article>
        ))}
      </div>
    </section>
  );
}

function Comparison() {
  return (
    <section className="section comparison-section">
      <div className="comparison-intro">
        <h2>Why operators choose Propvora</h2>
        <p>From manual and disconnected to automated and in control.</p>
      </div>

      <div className="comparison-table" aria-label="Before and after Propvora">
        <div className="comparison-header">
          <span>Before Propvora</span>
          <span>With Propvora</span>
        </div>
        {comparisonRows.map(([before, after]) => (
          <div className="comparison-row" key={before}>
            <div className="before">
              <span className="tiny-icon muted"><Icon name="building" /></span>
              {before}
            </div>
            <span className="arrow-line">→</span>
            <div className="after">
              <span className="tiny-icon good"><CheckIcon /></span>
              {after}
            </div>
          </div>
        ))}
      </div>

      <aside className="advantage-card">
        <h3>The Propvora advantage</h3>
        <ul>
          {[
            "Save hours every week",
            "Stay compliant & reduce risk",
            "Improve cash flow visibility",
            "Reduce admin & human error",
            "Scale with confidence",
          ].map((item) => (
            <li key={item}><span><CheckIcon /></span>{item}</li>
          ))}
        </ul>
      </aside>
    </section>
  );
}

function PlatformOverview() {
  const rows = [
    ["Aurora Office Tower", "Manchester", "Office", "48", "96%", "2", "100%"],
    ["Harbour View Retail", "Bristol", "Retail", "16", "100%", "1", "98%"],
    ["Riverside Industrial Park", "Birmingham", "Industrial", "24", "88%", "3", "95%"],
    ["The Ivy Residences", "Leeds", "Residential", "32", "92%", "4", "97%"],
    ["Northpoint Student Living", "Nottingham", "Student", "120", "94%", "2", "100%"],
  ];

  return (
    <section className="section platform-section">
      <div className="platform-copy">
        <h2>All the tools you need. One platform.</h2>
        <p>A complete suite of modules designed for modern property operators.</p>
      </div>

      <div className="module-tabs" aria-label="Platform modules">
        {modules.map((module, index) => (
          <button className={index === 0 ? "active" : ""} key={module}>
            {module}
          </button>
        ))}
      </div>

      <div className="platform-preview">
        <div className="map-card" aria-label="Portfolio map preview">
          {[1, 2, 3, 4, 5].map((pin) => (
            <span className={`pin pin-${pin}`} key={pin} />
          ))}
          <div className="map-road road-1" />
          <div className="map-road road-2" />
          <div className="map-road road-3" />
        </div>

        <div className="property-table-card">
          <div className="table-topbar">
            <div>
              <p className="overline">Properties</p>
              <h3>Portfolio register</h3>
            </div>
            <div className="table-filters">
              <span>All regions</span>
              <span>All types</span>
              <span>Status</span>
              <span className="fake-search">Search properties…</span>
            </div>
            <button>+ Add property</button>
          </div>
          <table>
            <thead>
              <tr>
                <th>Property</th>
                <th>Type</th>
                <th>Units</th>
                <th>Occupancy</th>
                <th>Work</th>
                <th>Compliance</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((row, index) => (
                <tr key={row[0]}>
                  <td>
                    <span className={`property-thumb thumb-${index + 1}`} />
                    <span>
                      <strong>{row[0]}</strong>
                      <small>{row[1]}</small>
                    </span>
                  </td>
                  <td>{row[2]}</td>
                  <td>{row[3]}</td>
                  <td>{row[4]}</td>
                  <td>{row[5]}</td>
                  <td><span className="status-good">{row[6]}</span></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="phone-mock" aria-label="Mobile app preview">
          <div className="phone-speaker" />
          <div className="phone-screen">
            <p className="phone-title">Overview</p>
            <div className="phone-grid">
              <span><strong>124</strong>Total properties</span>
              <span><strong>342</strong>Active tenancies</span>
              <span><strong>98%</strong>Compliance</span>
              <span><strong>£82.4k</strong>Invoices</span>
            </div>
            <div className="phone-chart" />
            <div className="phone-nav">
              <span />
              <span />
              <span />
              <span />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function SupplierMarketplace() {
  return (
    <section className="section supplier-section" id="suppliers">
      <div className="supplier-copy">
        <h2>Access verified contractors, matched to your patch</h2>
        <p>
          Our supplier marketplace connects you with trusted professionals who deliver
          quality work, on time.
        </p>
        <div className="supplier-badges">
          {["Verified & insured", "Rated by operators", "Fast response", "Competitive pricing", "UK wide coverage"].map((badge) => (
            <span key={badge}><CheckIcon /> {badge}</span>
          ))}
        </div>
      </div>

      <div className="trade-carousel">
        <button className="carousel-arrow">‹</button>
        {supplierTrades.map((trade) => (
          <article className="trade-card" key={trade.title}>
            <div className="trade-icon"><Icon name={trade.icon} /></div>
            <h3>{trade.title}</h3>
            <p><span>★</span> {trade.rating}</p>
            <small>{trade.pros}</small>
          </article>
        ))}
        <button className="carousel-arrow">›</button>
      </div>
    </section>
  );
}

function Pricing() {
  return (
    <section className="section pricing-section" id="pricing">
      <div className="section-heading compact">
        <h2>Simple, transparent pricing</h2>
      </div>

      <div className="pricing-grid">
        {pricingPlans.map((plan) => (
          <article className={`pricing-card ${plan.featured ? "featured" : ""}`} key={plan.name}>
            {plan.featured && <div className="popular">Most popular</div>}
            <h3>{plan.name}</h3>
            <div className="price"><strong>{plan.price}</strong><span>/mo</span></div>
            <p>{plan.descriptor}</p>
            <ul>
              {plan.bullets.map((bullet) => (
                <li key={bullet}><CheckIcon /> {bullet}</li>
              ))}
            </ul>
            <a className={plan.featured ? "btn btn-primary" : "btn btn-soft"} href="#trial">
              Start free trial
            </a>
          </article>
        ))}

        <aside className="trial-card">
          <div className="gift-icon"><Icon name="spark" /></div>
          <h3>14-day free trial</h3>
          <ul>
            <li><CheckIcon /> No credit card required</li>
            <li><CheckIcon /> Cancel anytime</li>
            <li><CheckIcon /> Full access to all features</li>
          </ul>
          <a className="btn btn-primary" href="#demo">Book a demo</a>
        </aside>
      </div>
    </section>
  );
}

function Testimonials() {
  return (
    <section className="section testimonials-section">
      <div className="section-heading compact">
        <h2>Loved by property operators</h2>
      </div>
      <div className="testimonial-grid">
        {testimonials.map((testimonial, index) => (
          <article className="testimonial-card" key={testimonial.name}>
            <div className="stars">★★★★★</div>
            <p>“{testimonial.quote}”</p>
            <div className="person">
              <span className={`avatar avatar-${index + 1}`}>{testimonial.initials}</span>
              <div>
                <strong>{testimonial.name}</strong>
                <small>{testimonial.role}</small>
              </div>
            </div>
            <span className="tag">{testimonial.tag}</span>
          </article>
        ))}
      </div>
    </section>
  );
}

function FinalCta() {
  return (
    <section className="final-cta" id="trial">
      <div className="cta-brand">
        <Image src="/images/propvora-mark.png" alt="" width={74} height={74} />
        <div>
          <h2>Ready to run your operations smarter?</h2>
          <p>Join thousands of operators already using Propvora.</p>
        </div>
      </div>
      <div className="cta-actions">
        <a className="btn btn-primary" href="#pricing">Start free trial</a>
        <a className="btn btn-soft" href="#demo">Book a demo</a>
      </div>
      <div className="cta-points">
        <span><CheckIcon /> No credit card required</span>
        <span><Icon name="bolt" /> Setup in minutes</span>
        <span><CheckIcon /> Cancel anytime</span>
      </div>
    </section>
  );
}

function Footer() {
  const columns = [
    ["Product", ["Features", "Integrations", "AI Copilot", "Pricing", "Changelog"]],
    ["For Operators", ["Stays", "Suppliers", "Services", "Emergency", "Resources"]],
    ["Company", ["About us", "Careers", "Partners", "Press", "Contact"]],
    ["Legal", ["Terms of Service", "Privacy Policy", "Cookie Policy", "Data Processing", "Security"]],
    ["Contact", ["hello@propvora.com", "+44 20 1234 5678", "London, United Kingdom"]],
  ];

  return (
    <footer className="footer">
      <div className="footer-brand">
        <Image src="/images/propvora-logo.png" alt="Propvora" width={176} height={58} />
        <p>
          The all-in-one platform that unifies property operations, compliance,
          planning, work management, tenancies, suppliers, and financial control.
        </p>
        <div className="socials" aria-label="Social links">
          <span>in</span><span>𝕏</span><span>f</span><span>◎</span>
        </div>
      </div>

      <div className="footer-links">
        {columns.map(([title, links]) => (
          <div key={title as string}>
            <h3>{title}</h3>
            {(links as string[]).map((link) => <a href="#" key={link}>{link}</a>)}
          </div>
        ))}
      </div>

      <p className="copyright">© 2025 Propvora Ltd. All rights reserved.</p>
    </footer>
  );
}

export default function Home() {
  return (
    <main>
      <Header />
      <Hero />
      <TrustBar />
      <OperationTypes />
      <FeatureGrid />
      <OperatingModes />
      <Comparison />
      <PlatformOverview />
      <SupplierMarketplace />
      <Pricing />
      <Testimonials />
      <FinalCta />
      <Footer />
    </main>
  );
}
