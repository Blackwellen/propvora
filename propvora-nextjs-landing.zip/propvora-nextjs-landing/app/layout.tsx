import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Propvora — Property Operations Platform",
  description:
    "Propvora unifies property operations, compliance, planning, work management, tenancies, suppliers and financial control in one connected platform.",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
